package com.example.bmobexample.newfile;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.bmob.BmobProFile;
import com.bmob.btp.callback.LocalThumbnailListener;
import com.example.bmobexample.BaseActivity;
import com.example.bmobexample.R;

/**
 * ������������ͼ
 */
public class LocalThumbnailActivity extends BaseActivity{

	EditText edit_ratio,edit_width,edit_height;
	Button btn_thumbnail,btn_thumbnail1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_local_thumbnail);
		btn_thumbnail = (Button)findViewById(R.id.btn_thumbnail);
		btn_thumbnail1 = (Button)findViewById(R.id.btn_thumbnail1);

		edit_ratio = (EditText)findViewById(R.id.edit_ratio);
		edit_width = (EditText)findViewById(R.id.edit_width);
		edit_height = (EditText)findViewById(R.id.edit_height);
		
		btn_thumbnail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String localPath = "sdcard/test1.png";
				int modeId =Integer.parseInt(edit_ratio.getText().toString());

				BmobProFile.getInstance(LocalThumbnailActivity.this).getLocalThumbnail(localPath, modeId, new LocalThumbnailListener() {

					@Override
					public void onError(int statuscode, String errormsg) {
						// TODO Auto-generated method stub
						showToast("��������ͼ����ʧ�� :"+statuscode+","+errormsg);
					}

					@Override
					public void onSuccess(String thumbnailPath) {
						// TODO Auto-generated method stub
						showToast("��������ͼ�����ɹ�  :"+thumbnailPath);
					}
				});
			}
		});

		btn_thumbnail1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String localPath = "sdcard/test1.png";
				int modeId =Integer.parseInt(edit_ratio.getText().toString());
				int width =Integer.parseInt(edit_width.getText().toString());
				int height =Integer.parseInt(edit_height.getText().toString());

				BmobProFile.getInstance(LocalThumbnailActivity.this).getLocalThumbnail(localPath, modeId, width, height, new LocalThumbnailListener() {

					@Override
					public void onError(int statuscode, String errormsg) {
						// TODO Auto-generated method stub
						showToast("��������ͼ����ʧ�� :"+statuscode+","+errormsg);
					}

					@Override
					public void onSuccess(String thumbnailPath) {
						// TODO Auto-generated method stub
						showToast("��������ͼ�����ɹ�  :"+thumbnailPath);
					}
				});
			}
		});
		
	}

}
