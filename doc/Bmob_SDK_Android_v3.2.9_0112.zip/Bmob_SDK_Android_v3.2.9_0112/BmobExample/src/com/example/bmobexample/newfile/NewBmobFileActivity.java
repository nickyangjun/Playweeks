package com.example.bmobexample.newfile;

import java.util.Arrays;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;

import com.bmob.BmobPro;
import com.bmob.BmobProFile;
import com.bmob.btp.callback.DownloadListener;
import com.bmob.btp.callback.ThumbnailListener;
import com.bmob.btp.callback.UploadBatchListener;
import com.bmob.btp.callback.UploadListener;
import com.bmob.btp.file.BTPFileResponse;
import com.example.bmobexample.BaseActivity;
import com.example.bmobexample.R;

/**
 * @ClassName: NewBmobFileActivity
 * @Description: TODO
 * @author smile
 * @date 2014-10-24 ����2:33:40
 */
public class NewBmobFileActivity extends BaseActivity {
	
	protected ListView mListview;
	protected BaseAdapter mAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_file);
		initListView();
	}
	
	private void initListView(){
		mListview = (ListView) findViewById(R.id.list);
		mAdapter = new ArrayAdapter<String>(this, R.layout.item_list,
				R.id.tv_item, getResources().getStringArray(
						R.array.list_arrays));
		mListview.setAdapter(mAdapter);
		mListview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				testBmobPro(position + 1);
			}
		});

	}
	
	private void testBmobPro(int pos) {
		switch (pos) {
		case 1:
			upload();
			break;
		case 2:
			uploadBatchFile();
			break;
		case 3:
			download();
			break;
		case 4:
			clearCache();
			showToast("���������ɹ�");
			break;
		case 5:
			getCurrentCache();
			break;
		case 6:
			showToast("�ļ����ص�ַ��"+BmobPro.getInstance(this).getCacheDownloadDir());
			break;
		case 7:
			requestThumbnailTask();
			break;
		case 8:
			startActivity(new Intent(this, LocalThumbnailActivity.class));
			break;
		default:
			break;
		}
	}
	
	/**
	  * @Description:��һ�ļ��ϴ�
	  * @param  
	  * @return void
	  * @throws
	  */
	ProgressDialog dialog =null;
	
	private void upload(){
		dialog = new ProgressDialog(NewBmobFileActivity.this);
		String filePath = "sdcard/test1.png";
		dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);                 
		dialog.setTitle("�ϴ���...");
		dialog.setIndeterminate(false);               
		dialog.setCancelable(false);       
		dialog.setCanceledOnTouchOutside(false);  
		dialog.show();             
		BTPFileResponse response = BmobProFile.getInstance(NewBmobFileActivity.this).upload(filePath, new UploadListener() {
			
			@Override
			public void onSuccess(String fileName,String url) {
				// TODO Auto-generated method stub
				downloadName = fileName;
				dialog.dismiss();
				showLog("MainActivity -onSuccess :"+fileName+",Url = "+ url);
				showToast("�ļ����ϴ��ɹ���"+fileName);
			}
			
			@Override
			public void onProgress(int ratio) {
				// TODO Auto-generated method stub
				showLog("MainActivity -onProgress :"+ratio);
				dialog.setProgress(ratio);
			}
			
			@Override
			public void onError(int statuscode, String errormsg) {
				// TODO Auto-generated method stub
//				showLog("MainActivity -onError :"+statuscode +"--"+errormsg);
				dialog.dismiss();
				showToast("�ϴ�������"+errormsg);
			}
		});
		
		showLog("upload�������ص�code = "+response.getStatusCode());
	}
	
	/**
	  * @Title: updateBatchFile
	  * @Description: �ļ������ϴ�
	  * @param  
	  * @return void
	  * @throws
	  */
	private void uploadBatchFile(){
		dialog = new ProgressDialog(NewBmobFileActivity.this);
		String[] files = new String[]{"sdcard/test1.png","sdcard/temp.jpg","sdcard/test2.png"};
		dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);                 
		dialog.setTitle("�����ϴ���...");
		dialog.setIndeterminate(false);               
		dialog.setCancelable(false);       
		dialog.setCanceledOnTouchOutside(false);  
		dialog.setMax(files.length);
		dialog.show();
		BmobProFile.getInstance(NewBmobFileActivity.this).uploadBatch(files, new UploadBatchListener() {
			
			@Override
			public void onSuccess(boolean isFinish,String[] fileNames,String[] urls) {
				// TODO Auto-generated method stub
				if(isFinish){
					dialog.dismiss();
				}
				showToast(""+Arrays.asList(fileNames));
				showLog("NewBmobFileActivity -onSuccess :"+isFinish+"-----"+Arrays.asList(fileNames)+"----"+Arrays.asList(urls));
			}
			
			@Override
			public void onProgress(int curIndex, int curPercent, int total,
					int totalPercent) {
				// TODO Auto-generated method stub
				dialog.setProgress(curIndex);
				showLog("NewBmobFileActivity -onProgress :"+curIndex+"---"+curPercent+"---"+total+"----"+totalPercent);
			}
			
			@Override
			public void onError(int statuscode, String errormsg) {
				// TODO Auto-generated method stub
				showLog("NewBmobFileActivity -onError :"+statuscode+"--"+errormsg);
				dialog.dismiss();
				showToast("�����ϴ�������"+errormsg);
			}
		});
	}
	
	//test1
	private static String downloadName= "74aac5a79322437082d3fcd6bf1b985f.png";

	/**
	  * @Description: �ļ�����
	  * @param  
	  * @return void
	  * @throws
	  */
	private void download(){
		if(downloadName.equals("")){
			showLog("��ָ�������ļ���");
			return;
		}
		dialog = new ProgressDialog(NewBmobFileActivity.this);
		dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);                 
		dialog.setTitle("������...");
		dialog.setIndeterminate(false);               
		dialog.setCancelable(false);       
		dialog.setCanceledOnTouchOutside(false);  
		dialog.show();
		BmobProFile.getInstance(NewBmobFileActivity.this).download(downloadName, new DownloadListener() {
			
			@Override
			public void onSuccess(String fullPath) {
				// TODO Auto-generated method stub
				showLog("MainActivity -download-->onSuccess :"+fullPath);
				dialog.dismiss();
				showToast("���سɹ���"+fullPath);
			}
			
			@Override
			public void onProgress(String localPath, int percent) {
				// TODO Auto-generated method stub
				showLog("MainActivity -download-->onProgress :"+percent);
				dialog.setProgress(percent);
			}
			
			@Override
			public void onError(int statuscode, String errormsg) {
				// TODO Auto-generated method stub
				showLog("MainActivity -download-->onError :"+statuscode +"--"+errormsg);
				dialog.dismiss();
				showToast("���س�����"+errormsg);
			}
		});
	}
	
	/**
	  * @Description: �ύ�����������������ͼ������
	  * @param  
	  * @return void
	  * @throws
	  */
	private void requestThumbnailTask(){
		BmobProFile.getInstance(NewBmobFileActivity.this).submitThumnailTask(downloadName, 2, new ThumbnailListener() {
			
			@Override
			public void onSuccess(String thumbnailName,String thumbnailUrl) {
				// TODO Auto-generated method stub
				//������ͼ���ƺ͵�ַ����һ���Ǽ�ʱ���صģ���Ϊ�첽����
				showToast("�ύ�����������������ͼ������ɹ���:"+thumbnailName+"-->"+thumbnailUrl);
				showLog("MainActivity -onSuccess :"+thumbnailName+"-->"+thumbnailUrl);
			}
			
			@Override
			public void onError(int statuscode, String errormsg) {
				// TODO Auto-generated method stub
				showToast("�ύ�����������������ͼ������ʧ�ܣ�:"+statuscode+"---"+errormsg);
				showLog("MainActivity -onError :"+statuscode+"---"+errormsg);
			}
		});
	}
	
	
	/**
	  * @Title: clearCache
	  * @Description: �������
	  * @param  
	  * @return void
	  * @throws
	  */
	public void clearCache(){
		BmobPro.getInstance(NewBmobFileActivity.this).clearCache();
	}
	
	/**
	 * ��ȡ��ǰ�����С
	 */
	public void getCurrentCache(){
		String cacheSize = String.valueOf(BmobPro.getInstance(NewBmobFileActivity.this).getCacheFileSize());
		String formatSize = BmobPro.getInstance(NewBmobFileActivity.this).getCacheFormatSize();
		showToast("�ѻ����С��"+cacheSize+"----->"+formatSize);
	}

}
