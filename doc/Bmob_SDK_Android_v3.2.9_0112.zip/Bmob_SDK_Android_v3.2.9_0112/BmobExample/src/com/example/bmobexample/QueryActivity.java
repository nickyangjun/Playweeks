package com.example.bmobexample;

import java.util.ArrayList;
import java.util.List;

import com.example.bmobexample.bean.Person;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.CountListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;

/**
  * @ClassName: FindActivity
  * @Description: ��ѯ����
  * @author smile
  * @date 2014-12-8 ����2:49:57
  */
public class QueryActivity extends BaseActivity {
	
	protected ListView mListview;
	protected BaseAdapter mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_find);
		mListview = (ListView) findViewById(R.id.listview);
		mAdapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.tv_item, getResources().getStringArray(
				R.array.bmob_findtest_list));
		mListview.setAdapter(mAdapter);
		mListview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				testFind(position + 1);
			}
		});
	}
	
	private void testFind(int pos) {
		switch (pos) {
			case 1:
				queryObject();
				break;
			case 2:
				queryObjects();
				break;
			case 3:
				countObjects();
				break;
			case 4:
				compositeAndQuery();
				break;
			case 5:
				compositeOrQuery();
				break;
		}
	}
	
	
	private void queryObjects(){
		BmobQuery<Person> bmobQuery	 = new BmobQuery<Person>();
//		bmobQuery.addWhereEqualTo("age", 25);
//		bmobQuery.addWhereNotEqualTo("age", 25);
//		bmobQuery.addQueryKeys("objectId");
//		bmobQuery.setLimit(10);
//		bmobQuery.setSkip(15);
//		bmobQuery.order("createdAt");
//		bmobQuery.setCachePolicy(CachePolicy.CACHE_ELSE_NETWORK);	// �ȴӻ���ȡ���ݣ����û�еĻ����ٴ�����ȡ��
		bmobQuery.findObjects(this, new FindListener<Person>() {

			@Override
			public void onSuccess(List<Person> object) {
				// TODO Auto-generated method stub
				toast("��ѯ�ɹ�����"+object.size()+"�����ݡ�");
				for (Person person : object) {
					Log.d(TAG, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ");
					Log.d(TAG, "ObjectId = "+person.getObjectId());
					Log.d(TAG, "Name = "+person.getName());
					Log.d(TAG, "Age = "+person.getAge());
					Log.d(TAG, "Address = "+person.getAddress());
					Log.d(TAG, "Gender = "+person.isGender());
					Log.d(TAG, "CreatedAt = "+person.getCreatedAt());
					Log.d(TAG, "UpdatedAt = "+person.getUpdatedAt());
				}
			}

			@Override
			public void onError(int code, String msg) {
				// TODO Auto-generated method stub
				toast("��ѯʧ�ܣ�"+msg);
			}
		});
	}
	
	private void queryObject(){
		BmobQuery<Person> bmobQuery	 = new BmobQuery<Person>();
//		bmobQuery.addWhereEqualTo("age", 25);
//		bmobQuery.addWhereNotEqualTo("age", 25);
//		bmobQuery.setCachePolicy(CachePolicy.CACHE_ELSE_NETWORK);	// �ȴӻ���ȡ���ݣ����û�еĻ����ٴ�����ȡ��
		bmobQuery.getObject(this, "d99bcbf506", new GetListener<Person>() {
			
			@Override
			public void onSuccess(Person object) {
				// TODO Auto-generated method stub
				toast("��ѯ�ɹ���"+object.getObjectId());
				Log.d(TAG, "ObjectId = "+object.getObjectId());
				Log.d(TAG, "Name = "+object.getName());
				Log.d(TAG, "Age = "+object.getAge());
				Log.d(TAG, "Address = "+object.getAddress());
				Log.d(TAG, "Gender = "+object.isGender());
				Log.d(TAG, "CreatedAt = "+object.getCreatedAt());
				Log.d(TAG, "UpdatedAt = "+object.getUpdatedAt());
			}

			@Override
			public void onFailure(int code, String arg0) {
				// TODO Auto-generated method stub
				toast("��ѯʧ�ܣ�"+arg0);
			}
			
		});
	}
	
	private void countObjects(){
		BmobQuery<Person> bmobQuery = new BmobQuery<Person>();
		bmobQuery.count(this, Person.class, new CountListener() {
			
			@Override
			public void onSuccess(int count) {
				// TODO Auto-generated method stub
				toast("count�������Ϊ��"+count);
			}
			
			@Override
			public void onFailure(int code, String msg) {
				// TODO Auto-generated method stub
				toast("count�������ʧ�ܣ�"+msg);
			}
		});
	}
	
	/**
	  * @Description: �������ѯ����ѯ����6-29��֮�䣬������"y"����"e"��β����
	  * @param  
	  * @return void
	  * @throws
	  */
	private void compositeAndQuery(){
		//��ѯ����6-29��֮����ˣ�ÿһ����ѯ��������Ҫnewһ��BmobQuery����
		//--and����1
		BmobQuery<Person> eq1 = new BmobQuery<Person>();
		eq1.addWhereLessThanOrEqualTo("age", 29);//����<=29
		//--and����2
		BmobQuery<Person> eq2 = new BmobQuery<Person>();
		eq2.addWhereGreaterThanOrEqualTo("age", 6);//����>=6

		//��ѯ������"y"����"e"��β����--�����Ҫʹ�õ�or��ѯ
		//--and����3
		BmobQuery<Person> eq3 = new BmobQuery<Person>();
		eq3.addWhereEndsWith("name", "y");
		BmobQuery<Person> eq4 = new BmobQuery<Person>();
		eq4.addWhereEndsWith("name", "e");
		List<BmobQuery<Person>> queries = new ArrayList<BmobQuery<Person>>();
		queries.add(eq3);
		queries.add(eq4);
		BmobQuery<Person> mainQuery = new BmobQuery<Person>();
		BmobQuery<Person> or = mainQuery.or(queries);

		//�����װ������and����
		List<BmobQuery<Person>> andQuerys = new ArrayList<BmobQuery<Person>>();
		andQuerys.add(eq1);
		andQuerys.add(eq1);
		andQuerys.add(or);
		//��ѯ��������and��������
		BmobQuery<Person> query = new BmobQuery<Person>();
		query.and(andQuerys);
		query.findObjects(this, new FindListener<Person>() {
		    @Override
		    public void onSuccess(List<Person> object) {
		        // TODO Auto-generated method stub
		    	toast("��ѯ����6-29��֮�䣬������'y'����'e'��β���˸�����"+object.size());
		    }
		    @Override
		    public void onError(int code, String msg) {
		        // TODO Auto-generated method stub
		    	toast("���ϲ�ѯʧ�ܣ�"+code+",msg:"+msg);
		    }
		});
	}
	
	/**
	 * @Description: ���ϻ��ѯ����ѯage ���� 29 ���� age ���� 6 ����
	 * @param  
	 * @return void
	 * @throws
	 */
	private void compositeOrQuery(){
		BmobQuery<Person> eq2 = new BmobQuery<Person>();
		eq2.addWhereEqualTo("age", 6);
		BmobQuery<Person> eq1 = new BmobQuery<Person>();
		eq1.addWhereEqualTo("age", 29);
		List<BmobQuery<Person>> queries = new ArrayList<BmobQuery<Person>>();
		queries.add(eq1);
		queries.add(eq2);
		BmobQuery<Person> mainQuery = new BmobQuery<Person>();
		mainQuery.or(queries);
		mainQuery.findObjects(this, new FindListener<Person>() {
			@Override
			public void onSuccess(List<Person> object) {
				// TODO Auto-generated method stub
				toast("����Ϊ29����6���˵ĸ�����"+object.size());
			}
			@Override
			public void onError(int code, String msg) {
				// TODO Auto-generated method stub
				toast("���ϲ�ѯʧ�ܣ�"+code+",msg:"+msg);
			}
		});
	}

}
